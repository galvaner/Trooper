./refine_model_mmtk.py -m mini_template.pdb -y 100 -o mini_out.pdb 
