./refine_model_mmtk.py -m single_resi.pdb -y 100 -o mini_out.pdb 
