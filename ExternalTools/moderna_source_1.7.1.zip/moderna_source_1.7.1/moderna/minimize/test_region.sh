./refine_model_mmtk.py -m mini_template.pdb -y 100 -r 7-9 -o mini_out.pdb 
