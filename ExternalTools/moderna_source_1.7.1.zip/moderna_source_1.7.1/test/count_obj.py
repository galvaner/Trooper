#!/usr/bin/env python

#from unittest import main, TestCase
#from moderna.moderna import *
from Bio import PDB

#t = load_template('test_data/gaps/gap1_template.pdb','B')
#a = load_alignment('test_data/gaps/gap1_alignment.fasta')
#m = create_model(t, a)

from get_all_obj import print_all_objects
print_all_objects()

